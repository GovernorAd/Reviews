export const env = {
  apiUrl: (import.meta.env.VITE_API_URL || '/api').replace(/\/+$/, ''),
} as const
